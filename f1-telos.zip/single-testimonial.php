<?php
/*
 * Testimonials CPT Single
 *
 * @package F1 Telos Tennis
 * @author Factor1 Studios
 * @since 0.0.1
 */

wp_redirect( get_post_type_archive_link('testimonial') ); ?>
