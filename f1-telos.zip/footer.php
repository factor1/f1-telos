<?php // Close main ?>
</main>

<?php // Site footer
get_template_part('parts/global/site-footer');

// Modals
get_template_part('parts/global/modals');

wp_footer(); ?>

</body>
</html>
