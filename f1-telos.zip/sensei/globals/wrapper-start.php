<?php
/**
 * Content wrappers Start
 *
 * All support theme wrappers can be found in includes/theme-integrations
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

//get_template_part('parts/global/hero'); ?>

<div class="centered-text-block">
  <div class="container">
    <div class="row">
      <div class="col-12">

        <div id="content" class="page col-full">
            <div id="main" class="col-left">
