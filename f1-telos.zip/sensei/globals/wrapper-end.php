<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Content wrappers
 *
 * All support theme wrappers can be found in includes/theme-integrations
 *
 * @author 		Automattic
 * @package 	Sensei
 * @category    Templates
 * @version     1.9.0
 */
?>
        </div>
        <?php get_sidebar(); ?>
</div>
</div>
</div>
</div>
</div>
